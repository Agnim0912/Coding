from tkinter import *
from tkinter import ttk
import sqlite3
sum = 0
new_sum = 0
master = Tk()
master.geometry("1200x700")
master.config(background='yellow')
finalbill=''

def fnc():
    conn = sqlite3.connect("menu6.db")
    c = conn.cursor()
    global sum
    global out
    global finalbill
    tno  = int(entry1.get())
    txt  = int(entry2.get())
    qnty = int(entry3.get())
    if (tno == 1):
        c.execute("SELECT * FROM food")
        a = c.fetchall()
        for u in a:
            if u[0] == txt:
                co = u[2]
        sum += co*qnty
        out="cost of item:",co*qnty
        finalbill = str(out)+'\n'

    elif (tno == 2):
        c.execute("SELECT * FROM accessories")
        a = c.fetchall()
        for u in a:
            if u[0] == txt:
                co = u[2]
        sum += co
        out="cost of item:",co*qnty
        finalbill += str(out)+'\n'

    elif (tno == 3):
        c.execute("SELECT * FROM home_accessories ")
        a = c.fetchall()
        for u in a:
            if u[0] == txt:
                co = u[2]
        sum += co
        out="cost of item:",co*qnty
        finalbill += str(out)+'\n'

    elif (tno == 4):
        c.execute("SELECT * FROM sports")
        a = c.fetchall()
        for u in a:
            if u[0] == txt:
                co = u[2]
        sum += co
        out="cost of item:",co*qnty
        finalbill += str(out)+'\n'

    else :
        print ("You have entered the wrong table no. respectively")
    c.close()
    entry1.delete(0, END)
    entry2.delete(0, END)
    entry3.delete(0, END)

def date():
    d = dat.get()
    m = mont.get()
    date = '2019'
    date = date+str(m)+str(d)
    date = int(date)
    return date

def discount_names():
    global new_sum
    global finalbill
    conn = sqlite3.connect("offers.db")
    c = conn.cursor()
    val=date()
    sq = ("select discount from discounts where {dt} between date_start and date_stop".format(dt=val))
    c.execute(sq)
    a = c.fetchall()
    disc = 0
    for i in a:
        for j in i:
            disc = int(j)
    new_sum = sum - (sum*(disc/100))
    bill = "Bill is:",sum
    finalbill += str(bill)+'\n'
    if disc==0:
        sp = "Bill is:",new_sum
        finalbill += str(sp)+'\n'
    if disc!=0:
        dis = "Discounted bill is:",new_sum
        finalbill += str(dis)+'\n'

def submit():
    global finalbill
    discount_names()
    bb.insert(0.0,finalbill)

heading    = Label(master, text="BIG BAZAAR BILLING COUNTER", font="Elephant 10", bg="red", width=90, relief="solid", bd=2)
heading2   = Label(master, text="Table Number", font="Arial 10 bold", bg='yellow')
heading3   = Label(master, text="Item Number", font="Arial 10 bold", bg='yellow')
heading4   = Label(master, text="Quantity", font="Arial 10 bold", bg='yellow')
heading5   = Label(master, text="Enter Duration", font="Arial 10 bold", bg='yellow')
button1    = Button(master, command=fnc, height=1, width=15, text="Enter", relief="solid", bd=2, bg="orange")
button2    = Button(master, height=1, width=15, text="Calculate", relief="solid", bd=2, bg="orange", command=submit)
entry1     = Entry(master, width=20, bg= "light grey", relief="solid", bd=2)
entry2     = Entry(master, width=20, bg= "light grey", relief="solid", bd=2)
entry3     = Entry(master, width=20, bg= "light grey", relief="solid", bd=2)
dat        = ttk.Combobox(master,values=["01","02","03","04","05","06","07","08","09","10","11","12","13","14","15","16","17","18","19","20","21","22","23","24","25","26","27","28","29","30","31"])
mont       = ttk.Combobox(master,values=["01","02","03","04","05","06","07","08","09","10","11","12"])
tableh1    = Label(master, text="1.FOOD\n   S.No.                 Item                 Price",font="Arial 8 bold", width=28, height=2, bg="magenta", anchor=W, relief="solid")
tablem1    = Label(master, text=" 01\n 02\n 03\n 04\n 05\n 06\n 07\n 08\n 09\n 10\n 11\n 12\n 13\n 14\n 15", width=6, height=15, bg="violet", anchor=CENTER, relief="solid")
tablem2    = Label(master, text="cereals\npulses\npizza\ncakes\nsoup\nbiscuits\nchips\nchocolates\ncandies\ndairy products\nfruits\nvegetables\nice cream\nsoft drink\nmineral water", width=13, height=15, bg="violet", anchor=CENTER, relief="solid")
tablem3    = Label(master, text="500\n400\n300\n150\n100\n50\n50\n50\n30\n60\n60\n50\n150\n50\n30", width=6, height=15, bg="violet", anchor=CENTER, relief="solid")
tableh2    = Label(master, text="2.ACCESSORIES\n   S.No.                 Item                 Price",font="Arial 8 bold", width=28, height=2, bg="magenta", anchor=W, relief="solid")
tablem4    = Label(master, text=" 01\n 02\n 03\n 04\n 05\n 06\n 07\n 08\n 09\n 10\n 11\n 12\n 13\n 14\n 15", width=6, height=15, bg="violet", anchor=CENTER, relief="solid")
tablem5    = Label(master, text=" smartphones\n laptops\n headphones\n speaker\n watches\n mixer\n mouse\n keyboard\n tablets\n consoles\n television\n washing machine\n water purifiers\n refrigerators\n air conditioners", width=13, height=15, bg="violet", anchor=CENTER, relief="solid")
tablem6    = Label(master, text=" 15000\n 50000\n 2000\n 5000\n 6000\n 1000\n 300\n 500\n 9000\n 13000\n 40000\n 15000\n 12000\n 19000\n 30000", width=6, height=15, bg="violet", anchor=CENTER, relief="solid")
tableh3    = Label(master, text="3.HOME ACCESSORIES\n   S.No.                 Item                 Price",font="Arial 8 bold", width=28, height=2, bg="magenta", anchor=W, relief="solid")
tablem7    = Label(master, text=" 01\n 02\n 03\n 04\n 05\n 06\n 07\n 08\n 09\n 10\n 11\n 12\n 13\n 14\n 15", width=6, height=15, bg="violet", anchor=CENTER, relief="solid")
tablem8    = Label(master, text=" Carpets\n chairs\n dining set\n cutlery\n curtains\n sofa\n bean bags\n paintings\n candles\n lamps\n sculptures\n posters\n looking mirors\n windchimes\n bedsheets", width=13, height=15, bg="violet", anchor=CENTER, relief="solid")
tablem9    = Label(master, text=" 500\n 1000\n 4000\n 600\n 5000\n 17000\n 5000\n 1000\n 100\n 1000\n 1000\n 500\n 2000\n 1000\n 3000", width=6, height=15, bg="violet", anchor=CENTER, relief="solid")
tableh4    = Label(master, text="4.SPORTS\n   S.No.                 Item                 Price",font="Arial 8 bold", width=28, height=2, bg="magenta", anchor=W, relief="solid")
tablem10   = Label(master, text=" 01\n 02\n 03\n 04\n 05\n 06\n 07\n 08\n 09\n 10\n 11\n 12\n 13\n 14\n 15", width=5, height=15, bg="violet", anchor=CENTER, relief="solid")
tablem11   = Label(master, text=" footballs\n bats\n cosco balls\n table tennis balls\n basketballs\n tracksuits\n cricket helmets\n shinpads\n golf clubs\n hockey sticks\n leather balls\n skates\n badminton rackets\n cycles\n cricket kit bags", width=15, height=15, bg="violet", anchor=CENTER, relief="solid")
tablem12   = Label(master, text=" 500\n 700\n 40\n 100\n 300\n 1000\n 500\n 100\n 1000\n 800\n 200\n 500\n 1000\n 15000\n 3000", width=5, height=15, bg="violet", anchor=CENTER, relief="solid")
disch      = Label(master, text="DISCOUNT OFFERS\n S.No.               Offer                           Durarion                  Price   ",font="Arial 8 bold", width=45, height=2, bg="magenta", anchor=W, relief="solid")
discm1     = Label(master, text=" \n01\n 02\n 03\n 04\n", width=5, height=4, bg="violet", anchor=CENTER, relief="solid")
discm2     = Label(master, text="\n women's day\n summer\n monsoon\n diwali dhamaka\n", width=12, height=4, bg="violet", anchor=CENTER, relief="solid")
discm3     = Label(master, text="\n 07-03\n 20-06\n 25-07\n 20-10\n", width=9, height=4, bg="violet", anchor=CENTER, relief="solid")
discm4     = Label(master, text="\n 09-03\n 25-06\n 30-07\n 27-10\n", width=9, height=4, bg="violet", anchor=CENTER, relief="solid")
discm5     = Label(master, text="\n 20%\n 10%\n 10%\n 15%\n", width=5, height=4, bg="violet", anchor=CENTER, relief="solid")
bb         = Text(master, width=40, height=33, relief="solid", bg="light blue", bd=2)

heading    .pack(side=TOP, fill=X)
heading2   .place(x=40, y=45)
heading3   .place(x=340, y=45)
heading4   .place(x=620, y=45)
heading5   .place(x=865, y=45)
button1    .place(x=350, y=100)
button2    .place(x=750, y=100)
entry1     .place(x=145, y=45)
entry2     .place(x=435, y=45)
entry3     .place(x=685, y=45)
dat        .place(x=1015, y=40)
mont       .place(x=1015, y=60)
tableh1    .place(x=30, y=160)
tablem1    .place(x=30, y=200)
tablem2    .place(x=83, y=200)
tablem3    .place(x=185, y=200)
tableh2    .place(x=240, y=160)
tablem4    .place(x=240, y=200)
tablem5    .place(x=292, y=200)
tablem6    .place(x=393, y=200)
tableh3    .place(x=450, y=160)
tablem7    .place(x=450, y=200)
tablem8    .place(x=503, y=200)
tablem9    .place(x=604, y=200)
tableh4    .place(x=660, y=160)
tablem10   .place(x=660, y=200)
tablem11   .place(x=705, y=200)
tablem12   .place(x=820, y=200)
disch      .place(x=30, y=460)
discm1     .place(x=30, y=500)
discm2     .place(x=74, y=500)
discm3     .place(x=166, y=500)
discm4     .place(x=238, y=500)
discm5     .place(x=310, y=500)
bb         .place(x=870, y=160)

master.mainloop()