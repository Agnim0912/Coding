import tkinter as tk
from tkinter import ttk

app = tk.Tk()
app.geometry('200x100')


comboExample = ttk.Combobox(app,values=["January","February","March","April"]).place(x=1015, y=40)
#mont       = ttk.Combobox(master,values=["01","02","03","04","05","06","07","08","09","10","11","12"]).place(x=1015, y=60)
comboExample.