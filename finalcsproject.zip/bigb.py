import sqlite3
conn = sqlite3.connect("menu6.db")
c = conn.cursor()
# =============================================================================
c.execute ("""create table sports
           ( sno integer,
            item text,
            price integer);""")
# =============================================================================
#c.execute('''INSERT INTO food VALUES(01,"cereals",500),
#          (02,"pulses",400),
#          (03,"pizza",300),
#          (04,"cakes",150),
#          (05,"soup",100),
#          (06,"biscuits",50),
#          (07,"chips",50),
#          (08,"choclates",50),
#          (09,"candies",30),
#          (10,"dairy products",60),
#          (11,"fruits",60),
#          (12,"vegetables",50),
#          (13,"ice cream",150),
#          (14,"soft drink",50),
#          (15,"mineral water",30);''')
#c.execute('''INSERT INTO sports VALUES(01,"football",500),
#          (02,"bat",700),
#          (03,"cosco balls",40),
#          (04,"table tennis balls",100),
#          (05,"basketball",300),
#          (06,"tarcksuit",1000),
#          (07,"cricket helmet",500),
#          (08,"shinpads",100),
#          (09,"golf club",1000),
#          (10,"hockey stick",800),
#          (11,"leather ball",200),
#          (12,"skates",500),
#          (13,"badminton racquets",1000),
#          (14,"cycles",15000),
#          (15,"cricket kit bag",3000);''')


#c.execute('''INSERT INTO accessories VALUES(01,"smartphones",15000),
#          (02,"laptops",50000),
#          (03,"headphones",2000),
#          (04,"speakers",5000),
#          (05,"watches",6000),
#          (06,"mixer",1000),
#          (07,"mouse",300),
#          (08,"keyboard",500),
#          (09,"tablets",9000),
#          (10,"consoles",13000),
#          (11,"tv",40000),
#          (12,"washing machine",15000),
#          (13,"water purifier",12000),
#          (14,"refrigerator",19000),
#         (15,"air conditioner",30000);''')

#c.execute('''INSERT INTO home_accessories VALUES(01,"carpets",500),
#          (02,"chairs",1000),
#          (03,"dining set",4000),
#          (04,"cutlery",600),
#          (05,"curtains",5000),
#          (06,"sofa",17000),
#          (07,"bean bag",5000),
#          (08,"paintings",1000),
#          (09,"candles",100),
#          (10,"lamps",1000),
#          (11,"sculptures",1000),
#          (12,"posters",500),
#          (13,"looking mirrors",2000),
#          (14,"windchimes",1000),
#          (15,"bedsheets",3000);''')

#c.execute('''INSERT INTO sports VALUES(01,"football",500),
#          (02,"bat",700),
#          (03,"cosco balls",40),
#          (04,"table tennis balls",100),
#          (05,"basketball",300),
#          (06,"tarcksuit",1000),
#          (07,"cricket helmet",500),
#          (08,"shinpads",100),
#          (09,"golf club",1000),
#          (10,"hockey stick",800),
#          (11,"leather ball",200),
#          (12,"skates",500),
#          (13,"badminton racquets",1000),
#          (14,"cycles",15000),
#          (15,"cricket kit bag",3000);''')


c.execute('SELECT * from accessories')
conn.commit()
print (c.fetchall())
conn.close()
