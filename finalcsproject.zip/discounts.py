import sqlite3
conn = sqlite3.connect("offers.db")
c = conn.cursor()
c.execute(''' create table discounts
              (sno integer,
              offer text,
              date_start date,
              date_stop date,
              discount integer)''')
c.execute('''INSERT INTO discounts VALUES(01,"women's day sale",20190307,20190309,20),
          (02,"summer sale",20190620,20190625,10),
          (03,"monsoon sale",20190725,20190730,10),
          (04,"diwali dhamaka sale",20191020,20191027,15)''')
c.execute("SELECT * FROM discounts")
conn.commit()
print (c.fetchall())
conn.close()