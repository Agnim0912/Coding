import sqlite3
conn = sqlite3.connect("offers.db")
c = conn.cursor()
#sq = "select amount from discounts where 20190327 between 20190325 and 20190331"
val="20190308"
sq = ("select discount from discounts where {dt} between date_start and date_stop".format(dt=val))
c.execute(sq)
a=c.fetchall()
disc=0
for i in a:
    for j in i:
        disc=int(j)
print(j)
c.close()