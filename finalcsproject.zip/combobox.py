import tkinter as tk
from tkinter import ttk

app = tk.Tk()
app.geometry('200x100')



comboExample = ttk.Combobox(app,values=["January","February","March","April"])

comboExample.place(x=10,y=30)
def but():
    print(comboExample.get())
button=tk.Button(app, text="hulala", command=but).place(x=10,y=2)
app.mainloop()