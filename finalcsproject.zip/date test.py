from tkinter import *
root = Tk()
#from tkcalendar import *

#def cal_func():
#    def calval():
#        a = cal.get_date()
#        b = cal.get_displayed_month()
#        ls=list(a)
#        dt=''
#        for i in range(2):
#            ls.remove('/')
#            ls.pop(-1)
#        for i in ls:
#            dt+=i
#        dt += str(b[-1])
#        print(int(dt))

#    top=Toplevel(root)
#    cal = Calendar(top, width=12,selectmode="day", background='darkblue', foreground='white', borderwidth=2)
#    cal.pack(fill="both", expand=True)
#    btn=Button(top,text="Enter", command=calval)
#    btn.pack()
#btn2=Button(root, text="calendar", command=cal_func)
#btn2.pack()

n1=[1,2,3]
n2=[10,20,30]
n3=[100,200,300]
n4=['Subscribe']

root.geometry("200x100")
root.title("dropdown list")

var=StringVar(root)
var.set("Date")

set = OptionMenu(root, var, "one", n2, n3, n4)
set.pack()
print("value is:",var.get())
root.mainloop()