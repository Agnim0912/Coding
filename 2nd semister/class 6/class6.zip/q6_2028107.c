#include <stdio.h>

int main() {
    unsigned char a, b; // a = 0100 1011, b = 1100 0010
    printf("Enter the first number : ");
    scanf("%hhd", &a);
    printf("Enter the second number : ");
    scanf("%hhd", &b);
    int aLast = (a&0x0F) << 4; // 1011 0000
    a = (a&0xF0); // 0100 0000
    int bFirst = (b&0xF0) >> 4; // 0000 1100
    b = (b&0x0F); // 0000 0010
    a = a|bFirst; // 0100 1100
    b = aLast|b; // 1011 0010
    printf("First pattern : 0x%x or %d\n", a, a);
    printf("Second pattern : 0x%x or %d\n", b, b);
    return 0;
}