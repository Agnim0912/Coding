#include <stdio.h>

int main() {
    int inputVal;
    printf("Enter a number : ");
    scanf("%i", &inputVal);
    int middleTwo = inputVal&0x00018000;
    middleTwo = middleTwo >> 15;
    printf("The middle two bits are : 0x%x\n", middleTwo);
}